"use strict";
cc._RFpush(module, '09bf7CZO59G25r7cy+mx6w7', 'CustomComponent');
// gizmos\CustomComponent.js

cc.Class({
    'extends': cc.Component,
    properties: {
        _canvas: null,
        points: {
            'default': [],
            type: cc.Vec2
        }

    },

    onLoad: function onLoad() {
        var _this = this;

        this._canvas = cc.find('Canvas');

        this._canvas.on('mouseup', function (e) {
            var location = e.getLocation();
            var isContain = _this.check(location);
            cc.log(isContain);
        }, this);
    },

    check: function check(location) {
        var node = this.node;
        var pointInNode = node.convertToNodeSpaceAR(location);
        if (pointInNode.x < -node.width / 2 || pointInNode.x > node.width / 2 || pointInNode.y > node.height / 2 || pointInNode.y < -node.height / 2) {
            return false;
        }

        var i = undefined,
            j = undefined,
            c = false;

        var nvert = this.points.length;
        var testx = pointInNode.x;
        var testy = pointInNode.y;
        var vert = this.points;

        for (i = 0, j = nvert - 1; i < nvert; j = i++) {
            if (vert[i].y > testy != vert[j].y > testy && testx < (vert[j].x - vert[i].x) * (testy - vert[i].y) / (vert[j].y - vert[i].y) + vert[i].x) c = !c;
        }

        return c;
    }

});

cc._RFpop();