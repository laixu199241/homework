不规则按钮触发组件。
通过鼠标按下和鼠标移动添加边界，鼠标一旦释放，则失去对刚刚新增点的鼠标修改权，只能在组件上修改或删除，也可以用组件上的reset菜单项重置整个边界。

复用请拷贝项目中的packages文件夹和CustomComponent.js
点于多边形的位置判断算法见CustomComponent.js中check方法 原理详见http://blog.sina.com.cn/s/blog_73000beb0101d4m0.html
如若需要修改边界，填充等颜色， 详见packages/hello-world/custom-gizmo.js的两个polygon.fill polygon.stroke  修改后需要重新打开项目
以上。
