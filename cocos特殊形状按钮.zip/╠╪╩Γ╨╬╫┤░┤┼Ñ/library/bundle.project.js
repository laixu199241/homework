require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"CustomComponent":[function(require,module,exports){
"use strict";
cc._RFpush(module, '09bf7CZO59G25r7cy+mx6w7', 'CustomComponent');
// gizmos\CustomComponent.js

cc.Class({
    'extends': cc.Component,
    properties: {
        _canvas: null,
        points: {
            'default': [],
            type: cc.Vec2
        }

    },

    onLoad: function onLoad() {
        var _this = this;

        this._canvas = cc.find('Canvas');

        this._canvas.on('mouseup', function (e) {
            var location = e.getLocation();
            var isContain = _this.check(location);
            cc.log(isContain);
        }, this);
    },

    check: function check(location) {
        var node = this.node;
        var pointInNode = node.convertToNodeSpaceAR(location);
        if (pointInNode.x < -node.width / 2 || pointInNode.x > node.width / 2 || pointInNode.y > node.height / 2 || pointInNode.y < -node.height / 2) {
            return false;
        }

        var i = undefined,
            j = undefined,
            c = false;

        var nvert = this.points.length;
        var testx = pointInNode.x;
        var testy = pointInNode.y;
        var vert = this.points;

        for (i = 0, j = nvert - 1; i < nvert; j = i++) {
            if (vert[i].y > testy != vert[j].y > testy && testx < (vert[j].x - vert[i].x) * (testy - vert[i].y) / (vert[j].y - vert[i].y) + vert[i].x) c = !c;
        }

        return c;
    }

});

cc._RFpop();
},{}],"mouseTest":[function(require,module,exports){
"use strict";
cc._RFpush(module, '882084yJPZI65FRZK9fmogu', 'mouseTest');
// mouseTest\mouseTest.js

cc.Class({
    'extends': cc.Component,

    properties: {
        _canvas: null,
        points: {
            'default': [],
            type: cc.Vec2
        }
    },

    onLoad: function onLoad() {
        var _this = this;

        this._canvas = cc.find('Canvas');

        this._canvas.on('mouseup', function (e) {
            var location = e.getLocation();
            var isContain = _this.check(location);
            cc.log(isContain);
        }, this);
    },

    check: function check(location) {
        var node = this.node;
        var pointInNode = node.convertToNodeSpaceAR(location);
        if (pointInNode.x < -node.width / 2 || pointInNode.x > node.width / 2 || pointInNode.y > node.height / 2 || pointInNode.y < -node.height / 2) {
            return false;
        }

        var i = undefined,
            j = undefined,
            c = false;

        var nvert = this.points.length;
        var testx = pointInNode.x;
        var testy = pointInNode.y;
        var vert = this.points;

        for (i = 0, j = nvert - 1; i < nvert; j = i++) {
            if (vert[i].y > testy != vert[j].y > testy && testx < (vert[j].x - vert[i].x) * (testy - vert[i].y) / (vert[j].y - vert[i].y) + vert[i].x) c = !c;
        }

        return c;
    }
});

cc._RFpop();
},{}]},{},["CustomComponent","mouseTest"])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkY6L2NvY29zY3JlYXRvci9Db2Nvc0NyZWF0b3IxLjEuMS9yZXNvdXJjZXMvYXBwLmFzYXIvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsImFzc2V0cy9naXptb3MvQ3VzdG9tQ29tcG9uZW50LmpzIiwiYXNzZXRzL21vdXNlVGVzdC9tb3VzZVRlc3QuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMDliZjdDWk81OUcyNXI3Y3krbXg2dzcnLCAnQ3VzdG9tQ29tcG9uZW50Jyk7XG4vLyBnaXptb3NcXEN1c3RvbUNvbXBvbmVudC5qc1xuXG5jYy5DbGFzcyh7XG4gICAgJ2V4dGVuZHMnOiBjYy5Db21wb25lbnQsXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBfY2FudmFzOiBudWxsLFxuICAgICAgICBwb2ludHM6IHtcbiAgICAgICAgICAgICdkZWZhdWx0JzogW10sXG4gICAgICAgICAgICB0eXBlOiBjYy5WZWMyXG4gICAgICAgIH1cblxuICAgIH0sXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgICB0aGlzLl9jYW52YXMgPSBjYy5maW5kKCdDYW52YXMnKTtcblxuICAgICAgICB0aGlzLl9jYW52YXMub24oJ21vdXNldXAnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgICAgICAgdmFyIGxvY2F0aW9uID0gZS5nZXRMb2NhdGlvbigpO1xuICAgICAgICAgICAgdmFyIGlzQ29udGFpbiA9IF90aGlzLmNoZWNrKGxvY2F0aW9uKTtcbiAgICAgICAgICAgIGNjLmxvZyhpc0NvbnRhaW4pO1xuICAgICAgICB9LCB0aGlzKTtcbiAgICB9LFxuXG4gICAgY2hlY2s6IGZ1bmN0aW9uIGNoZWNrKGxvY2F0aW9uKSB7XG4gICAgICAgIHZhciBub2RlID0gdGhpcy5ub2RlO1xuICAgICAgICB2YXIgcG9pbnRJbk5vZGUgPSBub2RlLmNvbnZlcnRUb05vZGVTcGFjZUFSKGxvY2F0aW9uKTtcbiAgICAgICAgaWYgKHBvaW50SW5Ob2RlLnggPCAtbm9kZS53aWR0aCAvIDIgfHwgcG9pbnRJbk5vZGUueCA+IG5vZGUud2lkdGggLyAyIHx8IHBvaW50SW5Ob2RlLnkgPiBub2RlLmhlaWdodCAvIDIgfHwgcG9pbnRJbk5vZGUueSA8IC1ub2RlLmhlaWdodCAvIDIpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBpID0gdW5kZWZpbmVkLFxuICAgICAgICAgICAgaiA9IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIGMgPSBmYWxzZTtcblxuICAgICAgICB2YXIgbnZlcnQgPSB0aGlzLnBvaW50cy5sZW5ndGg7XG4gICAgICAgIHZhciB0ZXN0eCA9IHBvaW50SW5Ob2RlLng7XG4gICAgICAgIHZhciB0ZXN0eSA9IHBvaW50SW5Ob2RlLnk7XG4gICAgICAgIHZhciB2ZXJ0ID0gdGhpcy5wb2ludHM7XG5cbiAgICAgICAgZm9yIChpID0gMCwgaiA9IG52ZXJ0IC0gMTsgaSA8IG52ZXJ0OyBqID0gaSsrKSB7XG4gICAgICAgICAgICBpZiAodmVydFtpXS55ID4gdGVzdHkgIT0gdmVydFtqXS55ID4gdGVzdHkgJiYgdGVzdHggPCAodmVydFtqXS54IC0gdmVydFtpXS54KSAqICh0ZXN0eSAtIHZlcnRbaV0ueSkgLyAodmVydFtqXS55IC0gdmVydFtpXS55KSArIHZlcnRbaV0ueCkgYyA9ICFjO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGM7XG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzg4MjA4NHlKUFpJNjVGUlpLOWZtb2d1JywgJ21vdXNlVGVzdCcpO1xuLy8gbW91c2VUZXN0XFxtb3VzZVRlc3QuanNcblxuY2MuQ2xhc3Moe1xuICAgICdleHRlbmRzJzogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBfY2FudmFzOiBudWxsLFxuICAgICAgICBwb2ludHM6IHtcbiAgICAgICAgICAgICdkZWZhdWx0JzogW10sXG4gICAgICAgICAgICB0eXBlOiBjYy5WZWMyXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgICAgdGhpcy5fY2FudmFzID0gY2MuZmluZCgnQ2FudmFzJyk7XG5cbiAgICAgICAgdGhpcy5fY2FudmFzLm9uKCdtb3VzZXVwJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgIHZhciBsb2NhdGlvbiA9IGUuZ2V0TG9jYXRpb24oKTtcbiAgICAgICAgICAgIHZhciBpc0NvbnRhaW4gPSBfdGhpcy5jaGVjayhsb2NhdGlvbik7XG4gICAgICAgICAgICBjYy5sb2coaXNDb250YWluKTtcbiAgICAgICAgfSwgdGhpcyk7XG4gICAgfSxcblxuICAgIGNoZWNrOiBmdW5jdGlvbiBjaGVjayhsb2NhdGlvbikge1xuICAgICAgICB2YXIgbm9kZSA9IHRoaXMubm9kZTtcbiAgICAgICAgdmFyIHBvaW50SW5Ob2RlID0gbm9kZS5jb252ZXJ0VG9Ob2RlU3BhY2VBUihsb2NhdGlvbik7XG4gICAgICAgIGlmIChwb2ludEluTm9kZS54IDwgLW5vZGUud2lkdGggLyAyIHx8IHBvaW50SW5Ob2RlLnggPiBub2RlLndpZHRoIC8gMiB8fCBwb2ludEluTm9kZS55ID4gbm9kZS5oZWlnaHQgLyAyIHx8IHBvaW50SW5Ob2RlLnkgPCAtbm9kZS5oZWlnaHQgLyAyKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgaSA9IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIGogPSB1bmRlZmluZWQsXG4gICAgICAgICAgICBjID0gZmFsc2U7XG5cbiAgICAgICAgdmFyIG52ZXJ0ID0gdGhpcy5wb2ludHMubGVuZ3RoO1xuICAgICAgICB2YXIgdGVzdHggPSBwb2ludEluTm9kZS54O1xuICAgICAgICB2YXIgdGVzdHkgPSBwb2ludEluTm9kZS55O1xuICAgICAgICB2YXIgdmVydCA9IHRoaXMucG9pbnRzO1xuXG4gICAgICAgIGZvciAoaSA9IDAsIGogPSBudmVydCAtIDE7IGkgPCBudmVydDsgaiA9IGkrKykge1xuICAgICAgICAgICAgaWYgKHZlcnRbaV0ueSA+IHRlc3R5ICE9IHZlcnRbal0ueSA+IHRlc3R5ICYmIHRlc3R4IDwgKHZlcnRbal0ueCAtIHZlcnRbaV0ueCkgKiAodGVzdHkgLSB2ZXJ0W2ldLnkpIC8gKHZlcnRbal0ueSAtIHZlcnRbaV0ueSkgKyB2ZXJ0W2ldLngpIGMgPSAhYztcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBjO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiXX0=
